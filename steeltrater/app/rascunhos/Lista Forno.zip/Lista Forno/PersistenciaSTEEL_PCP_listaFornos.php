<?php

/* 
 * Classe que implementa a persistencia de listaFornos
 * 
 * @author Cleverton Hoffmann
 * @since 18/07/2018
 */

class PersistenciaSTEEL_PCP_listaFornos extends Persistencia{
    public function __construct() {
        parent::__construct();
        
        $this->setTabela('STEEL_PCP_listaFornos');
        
        $this->adicionaRelacionamento('op','op',true,true);
        $this->adicionaRelacionamento('prioridade','prioridade');
        $this->adicionaRelacionamento('sit', 'sit');
        $this->adicionaRelacionamento('data', 'data');
        $this->adicionaRelacionamento('hora', 'hora');
        $this->adicionaRelacionamento('usuario', 'usuario');
        $this->adicionaRelacionamento('fornocod', 'fornocod');
        $this->adicionaRelacionamento('dataEntForno', 'dataEntForno');
        $this->adicionaRelacionamento('horaEntForno', 'horaEntForno');
        $this->adicionaRelacionamento('nrMovForno', 'nrMovForno');
        $this->adicionaRelacionamento('tempforno', 'tempforno');
        
        $this->setSTop('100');
        $this->adicionaOrderBy('op', 1);
        
    }
}
