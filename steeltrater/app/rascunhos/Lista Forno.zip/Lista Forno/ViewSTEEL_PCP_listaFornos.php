<?php

/*
 * Classe que implementa as views 
 * 
 * @author Cleverton Hoffmann
 * @since 18/07/2018
 */

class ViewSTEEL_PCP_listaFornos extends View {

    public function criaConsulta() {
        parent::criaConsulta();

        $oOp = new CampoConsulta('OP', 'op');
        $oPri = new CampoConsulta('Prioridade', 'prioridade');
        $oSit = new CampoConsulta('Sit.', 'sit');
        $oData = new CampoConsulta('Data', 'data');
        $oHora = new CampoConsulta('Hora', 'hora');
        $oUser = new CampoConsulta('Usuário', 'usuario');
        $oCod = new CampoConsulta('Cod.', 'fornocod');
        $oCodfiltro = new Filtro($oCod, Filtro::CAMPO_TEXTO, 5);
        

        $this->setUsaAcaoExcluir(false);
        $this->setUsaAcaoAlterar(false);
        $this->setUsaAcaoIncluir(false);
        $this->setUsaAcaoVisualizar(true);
        $this->addFiltro($oCodfiltro);

        $this->setBScrollInf(false);
        $this->addCampos($oOp,$oPri,$oSit,$oData,$oHora,$oUser,$oCod);
    }

    public function criaTela() {
        parent::criaTela();


        $oOp = new Campo('OP.', 'op', Campo::TIPO_TEXTO, 2, 2, 12, 12);
        $oPri = new Campo('Prioridade', 'prioridade', Campo::TIPO_TEXTO, 2, 2, 12, 12);
        $oSit = new Campo('Sit.', 'sit', Campo::TIPO_TEXTO, 2, 2, 12, 12);
        $oData = new Campo('Data', 'data', Campo::TIPO_TEXTO, 4, 4, 12, 12);
        $oHora = new Campo('Hora', 'hora', Campo::TIPO_TEXTO, 2, 2, 12, 12);
        $oUser = new Campo('Usuário', 'usuario', Campo::TIPO_TEXTO, 2, 2, 12, 12);
        $oCod = new Campo('Cod.', 'fornocod', Campo::TIPO_TEXTO, 2, 2, 12, 12);

        $this->addCampos(array($oOp,$oPri,$oSit,$oData,$oHora,$oUser,$oCod));
    }

}
