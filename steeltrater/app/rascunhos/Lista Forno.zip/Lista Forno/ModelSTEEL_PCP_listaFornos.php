<?php

/*
 * Implementa a classe model
 * 
 * @author Cleverton Hoffmann
 * @since 18/07/2018
 */

class ModelSTEEL_PCP_listaFornos {

    private $op;
    private $prioridade;
    private $sit;
    private $data;
    private $hora;
    private $usuario;
    private $fornocod;
    private $dataEntForno;
    private $horaEntForno;
    private $nrMovForno;
    private $tempforno;

    function getOp() {
        return $this->op;
    }

    function getPrioridade() {
        return $this->prioridade;
    }

    function getSit() {
        return $this->sit;
    }

    function getData() {
        return $this->data;
    }

    function getHora() {
        return $this->hora;
    }

    function getUsuario() {
        return $this->usuario;
    }

    function getFornocod() {
        return $this->fornocod;
    }

    function getDataEntForno() {
        return $this->dataEntForno;
    }

    function getHoraEntForno() {
        return $this->horaEntForno;
    }

    function getNrMovForno() {
        return $this->nrMovForno;
    }

    function getTempforno() {
        return $this->tempforno;
    }

    function setOp($op) {
        $this->op = $op;
    }

    function setPrioridade($prioridade) {
        $this->prioridade = $prioridade;
    }

    function setSit($sit) {
        $this->sit = $sit;
    }

    function setData($data) {
        $this->data = $data;
    }

    function setHora($hora) {
        $this->hora = $hora;
    }

    function setUsuario($usuario) {
        $this->usuario = $usuario;
    }

    function setFornocod($fornocod) {
        $this->fornocod = $fornocod;
    }

    function setDataEntForno($dataEntForno) {
        $this->dataEntForno = $dataEntForno;
    }

    function setHoraEntForno($horaEntForno) {
        $this->horaEntForno = $horaEntForno;
    }

    function setNrMovForno($nrMovForno) {
        $this->nrMovForno = $nrMovForno;
    }

    function setTempforno($tempforno) {
        $this->tempforno = $tempforno;
    }

}
