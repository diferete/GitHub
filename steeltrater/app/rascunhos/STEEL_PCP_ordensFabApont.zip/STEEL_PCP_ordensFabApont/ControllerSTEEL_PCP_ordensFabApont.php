<?php

/* 
 * Implementa a classe controler
 * 
 * @author Cleverton Hoffmann
 * @since 18/07/2018
 */


class ControllerSTEEL_PCP_ordensFabApont extends Controller {
    public function __construct() {
        $this->carregaClassesMvc('STEEL_PCP_ordensFabApont');
    }
}
