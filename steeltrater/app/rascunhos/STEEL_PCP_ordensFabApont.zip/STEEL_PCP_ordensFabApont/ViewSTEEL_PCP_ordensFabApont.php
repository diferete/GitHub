<?php

/*
 * Classe que implementa as views 
 * 
 * @author Cleverton Hoffmann
 * @since 18/07/2018
 */

class ViewSTEEL_PCP_ordensFabApont extends View {

    public function criaConsulta() {
        parent::criaConsulta();

        $oOp = new CampoConsulta('OP', 'op');
        $oSeq = new CampoConsulta('Seq.', 'seq');
        $oCod = new CampoConsulta('Cod.', 'fornocod');
        $oDtent = new CampoConsulta('Data entrada', 'dataent_forno');
        $oHentr = new CampoConsulta('Hora entrada', 'horaent_forno');
        $oDtsaid = new CampoConsulta('Data saída', 'datasaida_forno');
        $oHsaida = new CampoConsulta('Hora saída', 'horasaida_forno');
        $oDescricaoopfiltro = new Filtro($oOp, Filtro::CAMPO_TEXTO, 5);
        

        $this->setUsaAcaoExcluir(false);
        $this->setUsaAcaoAlterar(false);
        $this->setUsaAcaoIncluir(false);
        $this->setUsaAcaoVisualizar(true);
        $this->addFiltro($oDescricaoopfiltro);

        $this->setBScrollInf(false);
        $this->addCampos($oOp,$oSeq,$oCod,$oDtent,$oHentr,$oDtsaid,$oHsaida);
    }

    public function criaTela() {
        parent::criaTela();


        $oOp = new Campo('OP', 'op', Campo::TIPO_TEXTO, 2, 2, 12, 12);
        $oSeq = new Campo('Seq.', 'seq', Campo::TIPO_TEXTO, 2, 2, 12, 12);
        $oCod = new Campo('Cod.', 'fornocod', Campo::TIPO_TEXTO, 2, 2, 12, 12);
        $oDtent = new Campo('Data entrada', 'dataent_forno', Campo::TIPO_TEXTO, 2, 2, 12, 12);
        $oHentr = new Campo('Hora entrada', 'horaent_forno', Campo::TIPO_TEXTO, 2, 2, 12, 12);
        $oDtsaid = new Campo('Data saída', 'datasaida_forno', Campo::TIPO_TEXTO, 2, 2, 12, 12);
        $oHsaida = new Campo('Hora saída', 'horasaida_forno', Campo::TIPO_TEXTO, 2, 2, 12, 12);
        
        $this->addCampos(array($oOp,$oSeq,$oCod,$oDtent,$oHentr,$oDtsaid,$oHsaida));
    }

}
