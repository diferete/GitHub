<?php

/*
 * Classe que implementa a persistencia STEEL_PCP_ordensFabApont
 * 
 * @author Cleverton Hoffmann
 * @since 18/07/2018
 */

class PersistenciaSTEEL_PCP_ordensFabApont extends Persistencia {

    public function __construct() {
        parent::__construct();

        $this->setTabela('STEEL_PCP_ordensFabApont');

        $this->adicionaRelacionamento('op', 'op', true, true);
        $this->adicionaRelacionamento('seq', 'seq', true, true);
        $this->adicionaRelacionamento('fornocod', 'fornocod');
        $this->adicionaRelacionamento('dataent_forno', 'dataent_forno');
        $this->adicionaRelacionamento('horaent_forno', 'horaent_forno');
        $this->adicionaRelacionamento('datasaida_forno', 'datasaida_forno');
        $this->adicionaRelacionamento('horasaida_forno', 'horasaida_forno');

        $this->setSTop('1000');
        $this->adicionaOrderBy('op', 0);
    }
}
